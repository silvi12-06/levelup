<template>
  <div class="page">
    <router-view />

    <!-- Menú inferior -->
    <nav class="bottom-menu">
      <router-link to="/">Inicio</router-link> |
      <router-link to="/about">Acerca de</router-link> |
      <router-link to="/reflexion">Reflexion</router-link>
    </nav>
     
  </div>
</template>

<style>

body, html{
  margin: 0;
  padding: 0;
}
.page {
  padding-bottom: 0px; /* Espacio para el menú inferior */
}

/* Estilo del menú inferior */
.bottom-menu {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;

  background: white;
  padding: 1rem;
  text-align: center;

  z-index: 999;
}

.bottom-menu a {
  color: black;
  margin: 0 10px;
  text-decoration: none;
}

.bottom-menu a.router-link-exact-active {
  font-weight: bold;
  text-decoration: underline;
}
</style>


