<template>
  <div class="pesas-container">
    <div class="pesa-lane" v-for="n in 8" :key="n" :style="{ top: (n * 12.5) + '%' }">
      <img 
        src="../assets/imagenes/pesa.png" 
        alt="Pesa" 
        class="img-pesa flying"
        v-for="i in 6" 
        :key="i"
        :style="{ 
          animationDelay: (i * 1.8 + (n % 4)) + 's',
          width: (40 + (n % 5) * 15) + 'px',
          animationDuration: (8 + (n % 3)) + 's'
        }"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: 'PesasFondo'
}
</script>

<style scoped>
.pesas-container {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 1;
  overflow: hidden;
}

.pesa-lane {
  position: absolute;
  left: 0;
  width: 100%;
  height: 12.5%;
}

.img-pesa.flying {
  position: absolute;
  top: 5%;
  transform: translateY(-50%);
  animation: flyRight linear infinite;
  animation-fill-mode: forwards;
  visibility: hidden;
}

@keyframes flyRight {
  0% {
    transform: translateX(-300px) translateY(-50%);
    opacity: 0;
    visibility: visible;
  }
  15% {
    opacity: 1;
  }
  85% {
    opacity: 1;
  }
  100% {
    transform: translateX(calc(100vw + 300px)) translateY(-50%);
    opacity: 0;
  }
}
</style>