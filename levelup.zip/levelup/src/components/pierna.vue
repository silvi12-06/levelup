<template>
  <div class="pierna-overlay" @click="handleClick">
    <img :src="imagen" alt="detalle pierna" class="pierna-img" :class="{ 'relajado': relajado }"/>

    <!-- INSTRUCCIONES -->
    <div class="instrucciones-overlay" v-if="!hasStarted">
      <p class="instrucciones-texto">
        {{ instrucciones }}
      </p>
    </div>

    <!-- BOTON SIGUIENTE -->
    <button 
      v-if="relajado && !mostrandoFinal"
      class="boton-siguiente"
     @click.stop="mostrarPantallaFinal"
    >
      SIGUIENTE
    </button>

    <!-- PANTALLA FINAL VERDE -->
    <div v-if="mostrandoFinal" class="pantalla-final-verde">
      <p class="frase-final">
        GRACIAS POR ESCUCHARME,<br>
        CUIDARME NO ES CAMBIARME,<br>
        ES ENTENDERME.<br>
      </p>
      <!-- BOTÓN REINICIARME -->
        <button 
          class="boton-reiniciar"
          @click.stop="reiniciarApp"
        >
          REINICIARME
        </button>
    </div>
  </div>
</template>

<script>
export default {
  props: ["id", "imagen", "instrucciones", "sonido"],

  data() {
    return {
      relajado: false,  
      hasStarted: false,
      mostrandoFinal: false
    }
  },

  methods: {
    handleClick() {
      if (!this.relajado) {
        this.relajado = true
        this.hasStarted = true
      }
    },
    mostrarPantallaFinal() {
      this.mostrandoFinal = true
    },

    reiniciarApp() {
      this.$emit('reiniciar')  
    },
    
  }
}
</script>

<style>
.pierna-overlay {
  position: fixed;
  inset: 0;
  background: rgb(152, 1, 1, 0.9);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 2000;
  cursor: pointer;
}

.pierna-img {
  max-width: 95vw;
  max-height: 90vh;
  object-fit: contain;
  filter: drop-shadow(0 0 90px rgba(180, 20, 20, 0.95));
  border-radius: 12px;

  animation:
    entrarSuave 2.2s cubic-bezier(0.16, 1, 0.3, 1) forwards,
    estirarMusculo 1.8s ease-in-out 2.2s forwards,
    vibrarTension 0.4s ease-in-out 4s infinite;
}

.pierna-img.relajado {
  animation: none !important;           
  transform: scale(1, 1) !important;     
  
}

@keyframes entrarSuave {
  0%   { transform: scale(0.1) translateY(100px); opacity: 0; }
  70%  { transform: scale(1.05); opacity: 1; }
  100% { transform: scale(1); opacity: 1; }
}

@keyframes estirarMusculo {
  0%   { transform: scale(1, 1); }
  40%  { transform: scale(0.90, 1.20); }
  70%  { transform: scale(0.85, 1.32); }   
  100% { transform: scale(0.88, 1.28); }   
}

@keyframes vibrarTension {
  0%   { transform: scale(0.88, 1.28) translate(0, 0); }
  15%  { transform: scale(0.89, 1.29) translate(-4px, -3px); }
  30%  { transform: scale(0.87, 1.27) translate(5px, 2px); }
  45%  { transform: scale(0.90, 1.30) translate(-3px, 4px); }
  60%  { transform: scale(0.86, 1.26) translate(4px, -5px); }
  75%  { transform: scale(0.89, 1.29) translate(-2px, -2px); }
  100% { transform: scale(0.88, 1.28) translate(0, 0); }
}

@keyframes relajarMusculo {
  0%   { transform: scale(0.88, 1.28); }
  100% { transform: scale(1, 1); }
}

/* BOTÓN SIGUIENTE */
.boton-siguiente {
  position: absolute;
  right: 40px;
  bottom: 60px;
  width: 250px;
  height: 60px;
  font-size: 2vw;
  font-weight: bold;
  color: white;
  background: rgba(180, 20, 20, 0.8);
  border: 4px solid rgba(255, 80, 80, 0.9);
  border-radius: 15px;
  cursor: pointer;
  text-transform: uppercase;
  letter-spacing: 0.15em;
  text-shadow: 0 0 20px rgba(255, 100, 100, 0.8);
  box-shadow: 0 0 40px rgba(255, 50, 50, 0.7);
  transition: all 0.3s ease;
  user-select: none;
  animation: pulsoBoton 2s ease-in-out infinite;
  z-index: 10;
  display: flex;
  justify-content: center;
  align-items: center;
}

.boton-siguiente:hover {
  background: rgba(200, 30, 30, 0.95);
  transform: translateY(-6px);
  box-shadow: 0 0 70px rgba(255, 80, 80, 1);
}

@keyframes pulsoBoton {
  0%, 100% { box-shadow: 0 0 40px rgba(255, 50, 50, 0.7); }
  50%      { box-shadow: 0 0 70px rgba(255, 80, 80, 1); }
}

/* INSTRUCCIONES*/
.instrucciones-overlay {
  position: absolute;
  top: 40px;    
  left: 40px;
  text-align: left;      
  z-index: 10;
  pointer-events: none;
  max-width: 32%;         
}

.instrucciones-texto {
  color: #ffffff;
  font-size: 1.4rem;           
  font-weight: bold;
  line-height: 1.5;
  margin: 0;
  padding: 0;
  background: none;             
  border: none;               
  border-radius: 0;             
  animation: fadeIn 1.5s ease-out;
}

@keyframes fadeIn {
  from { 
    opacity: 0; 
    transform: translateY(20px); 
  }
  to { 
    opacity: 1; 
    transform: translateY(0); 
  }
}

.cabeza-overlay.has-started .instrucciones-overlay {
  display: none;
}

/* PANTALLA FINAL VERDE */
.pantalla-final-verde {
  position: fixed;
  inset: 0;
  background: #28a745; 
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 3000;
  animation: fadeInSuave 1.2s ease-out forwards;
}

.frase-final {
  color: white;
  font-size: 2.6rem;
  font-weight: bold;
  text-align: center;
  padding: 30px;
  line-height: 1.6;
  max-width: 90%;
  animation: aparecerTexto 2s ease-out 0.8s forwards;
  opacity: 0;
}

@keyframes fadeInSuave {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes aparecerTexto {
  from { opacity: 0; transform: translateY(30px); }
  to { opacity: 1; transform: translateY(0); }
}

/* BOTÓN REINICIARME */
.boton-reiniciar {
  position: fixed;        
  width: 320px;
  height: 70px;
  right: 40px;              
  bottom: 70px;           
  font-size: 2.2rem;
  font-weight: bold;
  color: #28a745;
  background: white;
  border: 5px solid white;
  border-radius: 20px;
  cursor: pointer;
  text-transform: uppercase;
  letter-spacing: 0.15em;
  box-shadow: 0 0 50px rgba(255, 255, 255, 0.6);
  transition: all 0.4s ease;
  animation: pulsoBotonVerde 2.5s ease-in-out infinite;
  z-index: 1000;           
}

.boton-reiniciar:hover {
  transform: translateY(-8px) scale(1.05);
  box-shadow: 0 0 80px rgba(255, 255, 255, 0.9);
}

@keyframes pulsoBotonVerde {
  0%, 100% { 
    box-shadow: 0 0 50px rgba(255, 255, 255, 0.6); 
  }
  50% { 
    box-shadow: 0 0 90px rgba(255, 255, 255, 1); 
  }
}

@keyframes fadeInSuave {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes aparecerTexto {
  from { opacity: 0; transform: translateY(30px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>