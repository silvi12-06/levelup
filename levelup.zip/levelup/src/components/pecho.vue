<template>
  <div class="corazon-overlay" @click="calmarCorazon">
    <img :src="imagen" alt="detalle corazon" class="corazon-img" :class="{ 'calmado': estado === 'calmado' }"/>

    <!-- INSTRUCCIONES -->
    <div class="instrucciones-overlay" v-if="!hasStarted">
      <p class="instrucciones-texto">
        {{ instrucciones }}
      </p>
    </div>

    <!-- BOTON SIGUIENTE -->
    <button 
      v-if="estado === 'calmado'"
      class="boton-siguiente"
      @click.stop="$emit('close')"
    >
      SIGUIENTE
    </button>

    <!-- AUDIO -->
    <audio ref="audioLatido" :src="heartbeatSound" preload="auto"></audio>
  </div>
</template>

<script>
import heartbeatSound from '../assets/imagenes/hearbeat.mp3'

export default {
  props: ["id", "imagen","instrucciones", "sonido"],

  data() {
    return {
      heartbeatSound,
      estado: 'nervioso', 
      audio: null,
      hasStarted: false
    }
  },

  mounted() {
    this.audio = this.$refs.audioLatido
    this.iniciarTaquicardia()
  },

  methods: {
    iniciarTaquicardia() {
      if (!this.audio) return
      this.audio.loop = true
      this.audio.volume = 0.8
      this.audio.playbackRate = 1.95  
      this.audio.play()
    },

    calmarCorazon() {
      if (this.estado !== 'nervioso') return

      this.hasStarted = true

      this.estado = 'calmándose'

      let velocidad = 1.95
      const intervalo = setInterval(() => {
        velocidad -= 0.14
        if (velocidad <= 0.75) {
          velocidad = 0.75
          clearInterval(intervalo)
          this.estado = 'calmado'
          this.audio.pause()
        }
        this.audio.playbackRate = velocidad
      }, 380) 
    }
  },

  beforeDestroy() {
    if (this.audio) {
      this.audio.pause()
      this.audio.currentTime = 0
    }
  }
}
</script>

<style>
.corazon-overlay {
  position: fixed;
  inset: 0;
  background: rgb(152, 1, 1, 0.9);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 2000;
  cursor: pointer;
}

.corazon-img {
  width: 95vw;
  max-height: 80vh;
  object-fit: contain;
  filter: drop-shadow(0 0 60px rgba(255, 80, 80, 0.9));
  animation: 
    entrarSuave 0.9s cubic-bezier(0.2, 0.8, 0.2, 1) forwards,
    latidoNervioso 0.72s ease-in-out 1s infinite;
}

.corazon-img.calmado {
  animation: 
    entrarSuave 0.9s cubic-bezier(0.2, 0.8, 0.2, 1) forwards,
    latidoCalmado 1.8s ease-in-out 1s infinite !important;
  
}

@keyframes entrarSuave {
  0%   { transform: scale(0.2) translateY(60px); opacity: 0; }
  70%  { transform: scale(1.06); }
  100% { transform: scale(1); opacity: 1; }
}

/* Latido muy rápido y ansioso */
@keyframes latidoNervioso {
  0%    { transform: scale(1); }
  10%   { transform: scale(1.13); }
  22%   { transform: scale(1.04); }
  32%   { transform: scale(1.15); }
  42%   { transform: scale(1.06); }
  52%   { transform: scale(1); }
  100%  { transform: scale(1); }
}

/* Latido lento y tranquilo */
@keyframes latidoCalmado {
  0%    { transform: scale(1); }
  8%    { transform: scale(1.08); }
  16%   { transform: scale(1.02); }
  24%   { transform: scale(1.10); }
  32%   { transform: scale(1.04); }
  40%   { transform: scale(1.06); }
  50%   { transform: scale(1); }
  100%  { transform: scale(1); }
}

/* BOTON SIGUIENTE */
.boton-siguiente {
  position: absolute;
  right: 40px;
  bottom: 60px;
  width: 250px;
  height: 60px;
  font-size: 2vw;
  font-weight: bold;
  color: white;
  background: rgba(180, 20, 20, 0.8);
  border: 4px solid rgba(255, 80, 80, 0.9);
  border-radius: 15px;
  cursor: pointer;
  text-transform: uppercase;
  letter-spacing: 0.15em;
  text-shadow: 0 0 20px rgba(255, 100, 100, 0.8);
  box-shadow: 0 0 40px rgba(255, 50, 50, 0.7);
  transition: all 0.3s ease;
  user-select: none;
  animation: pulsoBoton 2s ease-in-out infinite;
  z-index: 10;
  display: flex;
  justify-content: center;
  align-items: center;
}

.boton-siguiente:hover {
  background: rgba(200, 30, 30, 0.95);
  transform: translateY(-6px);
  box-shadow: 0 0 70px rgba(255, 80, 80, 1);
}

@keyframes pulsoBoton {
  0%, 100% { box-shadow: 0 0 40px rgba(255, 50, 50, 0.7); }
  50%      { box-shadow: 0 0 70px rgba(255, 80, 80, 1); }
}


/* INSTRUCCIONES */
.instrucciones-overlay {
  position: absolute;
  top: 40px;     
  left: 40px;
  text-align: left;       
  z-index: 10;
  pointer-events: none;   
  max-width: 32%;         
}

.instrucciones-texto {
  color: #ffffff;
  font-size: 1.4rem;           
  font-weight: bold;
  line-height: 1.5;
  margin: 0;
  padding: 0;
  background: none;             
  border: none;                 
  border-radius: 0;             
  animation: fadeIn 1.5s ease-out;
}

@keyframes fadeIn {
  from { 
    opacity: 0; 
    transform: translateY(20px); 
  }
  to { 
    opacity: 1; 
    transform: translateY(0); 
  }
}

.cabeza-overlay.has-started .instrucciones-overlay {
  display: none;
}

</style>