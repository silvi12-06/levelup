<template>
  <div class="cabeza-overlay">
    <img :src="imagen" alt="detalle cabeza" class="cabeza-img" />

    <!-- INSTRUCCIONES -->
    <div class="instrucciones-overlay" v-if="!hasStarted">
      <p class="instrucciones-texto">
        {{ instrucciones }}
      </p>
    </div>
    
    <!-- FRASES INTERACTIVAS -->
    <div v-if="currentArray.length" class="frases-container">
      <p 
        v-for="(item, idx) in currentArray" 
        :key="item.pos"
        class="frase-item"
        :class="`pos-${item.pos}`"
        @click.stop="onPhraseClick(idx)"
      >
        {{ item.text }}
      </p>
    </div>
    <p v-else class="no-frase">No hay frases</p>

    <!-- BOTÓN SIGUIENTE -->
    <button v-if="selected === 'buenas' && buenasConPos.some(f => f.text.trim())" class="boton-siguiente" @click.stop="$emit('close')">
      SIGUIENTE
    </button>
  </div>
</template>

<script>
export default {
  props: ["id", "imagen","instrucciones", "fraseMala1", "fraseMala2","fraseMala3", "fraseBuena1", "fraseBuena2", "sonido"],
  data() {
    return {
      selected: 'malas',
      visibleMalas: [],
      hasStarted: false
    }
  },
  computed: {
    inicialMalas() {
      return [
        { text: this.fraseMala1 || '', pos: 0 },
        { text: this.fraseMala2 || '', pos: 1 },
        { text: this.fraseMala3 || '', pos: 2 }
      ]
    },
    buenasConPos() {
      return [
        { text: this.fraseBuena1 || '', pos: 3 },
        { text: this.fraseBuena2 || '', pos: 4 }
      ].filter(f => f.text.trim() !== '')  
    },
    currentArray() {
      return this.selected === 'malas' ? this.visibleMalas : this.buenasConPos
    }
  },
  created() {
    this.visibleMalas = this.inicialMalas.filter(i => i.text && i.text.trim() !== '')
  },
  methods: {
    onPhraseClick(idx) {
      if (this.selected === 'malas') {
        if (!this.hasStarted) {
          this.hasStarted = true;
        }

        this.visibleMalas.splice(idx, 1)
        if (this.visibleMalas.length === 0) {
          this.selected = 'buenas'
        }
      }
    }
  },
};
</script>

<style>
.cabeza-overlay {
  position: fixed;
  inset: 0;
  background: rgb(152, 1, 1, 0.9);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 2000;
  cursor: default; 
}

.cabeza-img {
  width: 95vw;
  height: auto;
  max-width: none;
  max-height: 80vh;
  object-fit: contain;
  transition: transform 0.2s ease;
}

/* Frases */
.frases-container {
  position: absolute;
  inset: 0;
  pointer-events: none;
}

.frase-item {
  position: absolute;
  margin: 0;
  padding: 10px 14px;
  color: #fff;
  border-radius: 8px;
  font-size: 0.95rem;
  cursor: pointer;
  pointer-events: auto;
  line-height: 1.2;
  max-width: 38vw;
  word-break: break-word;
  font-weight: bold;
}

/* Posiciones malas */
.frase-item.pos-0 { top: 19%; left: 50%; transform: translateX(-50%); }
.frase-item.pos-1 { top: 39%; right: 40%; transform: translateY(-50%); max-width: 28vw; }
.frase-item.pos-2 { bottom: 67%; left: 48%; transform: translateX(-50%); }

/* Posiciones buenas */
.frase-item.pos-3 { top: 24%; right: 45%; transform: none; color: #eafff0; }
.frase-item.pos-4 { bottom: 66%; left: 45%; transform: none; color: #eaf6ff; }

.no-frase {
  color: #fff;
  opacity: 0.7;
}

/* BOTÓN SIGUIENTE */
.boton-siguiente {
  position: absolute;
  right: 40px;
  bottom: 60px;
  width: 250px;
  height: 60px;
  font-size: 2vw;
  font-weight: bold;
  color: white;
  background: rgba(180, 20, 20, 0.7);
  border: 4px solid rgba(255, 80, 80, 0.9);
  border-radius: 15px;
  cursor: pointer;
  text-transform: uppercase;
  letter-spacing: 0.15em;
  text-shadow: 0 0 20px rgba(255, 100, 100, 0.8);
  box-shadow: 
    0 0 40px rgba(255, 50, 50, 0.6),
    inset 0 0 20px rgba(255, 100, 100, 0.3);
  transition: all 0.3s ease;
  user-select: none;
  animation: pulsoBoton 2.2s ease-in-out infinite;
  z-index: 10;
  display: flex;
  justify-content: center;
  align-items: center;
}

.boton-siguiente:hover {
  background: rgba(200, 30, 30, 0.9);
  border-color: rgba(255, 100, 100, 1);
  box-shadow: 
    0 0 60px rgba(255, 80, 80, 0.8),
    inset 0 0 30px rgba(255, 120, 120, 0.5);
  transform: translateY(-4px);
}

.boton-siguiente:active {
  transform: translateY(2px);
}

@keyframes pulsoBoton {
  0%, 100% { 
    box-shadow: 
      0 0 40px rgba(255, 50, 50, 0.6),
      inset 0 0 20px rgba(255, 100, 100, 0.3);
  }
  50% { 
    box-shadow: 
      0 0 70px rgba(255, 80, 80, 0.9),
      inset 0 0 35px rgba(255, 120, 120, 0.5);
  }
}

/* Responsivo */
@media (max-width: 768px) {
  .boton-siguiente {
    width: 200px;
    height: 50px;
    font-size: 18px;
    right: 20px;
    bottom: 40px;
  }
}

/* INSTRUCCIONES */
.instrucciones-overlay {
  position: absolute;
  top: 40px;     
  left: 40px;
  text-align: left;       
  z-index: 10;
  pointer-events: none;   
  max-width: 32%;         
}

.instrucciones-texto {
  color: #ffffff;
  font-size: 1.4rem;          
  font-weight: bold;
  line-height: 1.5;
  margin: 0;
  padding: 0;
  background: none;             
  border: none;                 
  border-radius: 0;             
  animation: fadeIn 1.5s ease-out;
}

@keyframes fadeIn {
  from { 
    opacity: 0; 
    transform: translateY(20px); 
  }
  to { 
    opacity: 1; 
    transform: translateY(0); 
  }
}

.cabeza-overlay.has-started .instrucciones-overlay {
  display: none;
}
</style>