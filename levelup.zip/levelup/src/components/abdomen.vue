<template>
  <div class="abdomen-overlay">
    <img ref="img" :src="imagen" alt="detalle abdomen" class="abdomen-img" :class="{ 'rotando': fase === 'rotando' }" @click="handleClick"/>
    
    <!-- INSTRUCCIONES -->
    <div class="instrucciones-overlay" v-if="!hasStarted">
      <p class="instrucciones-texto">
        {{ instrucciones }}
      </p>
    </div>

    <!-- BOTON SIGUIENTE  -->
    <button 
      v-if="fase === 'siguiente'" 
      class="boton-siguiente"
      @click="cerrar"
    >
      SIGUIENTE
    </button>
  </div>
</template>

<script>
export default {
  props: ["id", "imagen","instrucciones", "sonido"],

  data() {
    return {
      fase: 'rotando',  
      hasStarted: false
    }
  },

  methods: {
    handleClick() {
      if (this.fase === 'rotando') {
        this.fase = 'siguiente'
        this.hasStarted = true
      }
    },

    cerrar() {
      this.$emit('close')
    }
  }
}
</script>

<style>
.abdomen-overlay {
  position: fixed;
  inset: 0;
  background: rgb(152, 1, 1, 0.9);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  z-index: 2000;
  gap: 60px; 
  cursor: default;
}

.abdomen-img {
  width: 95vw;
  max-height: 60vh;
  object-fit: contain;
  filter: drop-shadow(0 0 80px rgba(180, 20, 20, 0.8));
  border-radius: 12px;
  cursor: pointer; 
  animation: entrarSuave 2.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
}

.abdomen-img.rotando {
  animation: 
    entrarSuave 2.5s cubic-bezier(0.16, 1, 0.3, 1) forwards,
    rotarCaosTotal 1.4s linear 2.5s infinite;
}

.abdomen-img:not(.rotando) {
  animation: 
    entrarSuave 2.5s cubic-bezier(0.16, 1, 0.3, 1) forwards,
    desaparecerCaotico 1.8s ease-in forwards;
}

/* BOTÓN SIGUIENTE */
.boton-siguiente {
  position: absolute;                  
  right: 40px;                         
  bottom: 75px;
  font-size: 2vw;
  font-weight: bold;
  color: white;
  background: rgba(180, 20, 20, 0.7);
  border: 4px solid rgba(255, 80, 80, 0.9);
  border-radius: 15px;
  cursor: pointer;
  text-transform: uppercase;
  letter-spacing: 0.15em;
  text-shadow: 0 0 20px rgba(255, 100, 100, 0.8);
  box-shadow: 
    0 0 40px rgba(255, 50, 50, 0.6),
    inset 0 0 20px rgba(255, 100, 100, 0.3);
  transition: all 0.3s ease;
  user-select: none;
  animation: pulsoBoton 2.2s ease-in-out infinite;
}

.boton-siguiente:hover {
  background: rgba(200, 30, 30, 0.9);
  border-color: rgba(255, 100, 100, 1);
  box-shadow: 
    0 0 60px rgba(255, 80, 80, 0.8),
    inset 0 0 30px rgba(255, 120, 120, 0.5);
  transform: scale(1.08);
  animation: none; 
}

.boton-siguiente:active {
  transform: scale(0.95);
  box-shadow: 0 0 80px rgba(255, 100, 100, 1);
}

/* Pulso constante del botón */
@keyframes pulsoBoton {
  0%, 100% { 
    transform: scale(1); 
    box-shadow: 
      0 0 40px rgba(255, 50, 50, 0.6),
      inset 0 0 20px rgba(255, 100, 100, 0.3);
  }
  50% { 
    transform: scale(1.06); 
    box-shadow: 
      0 0 70px rgba(255, 80, 80, 0.9),
      inset 0 0 35px rgba(255, 120, 120, 0.5);
  }
}

@keyframes entrarSuave {
  0%   { transform: scale(0.08) translateY(120px); opacity: 0; }
  65%  { transform: scale(1.06); opacity: 1; }
  100% { transform: scale(1); opacity: 1; }
}

@keyframes rotarCaosTotal {
  0%    { transform: rotate(0deg)   scale(1)     translate(0, 0); }
  8%    { transform: rotate(45deg)  scale(1.08)  translate(-15px, 10px); }
  16%   { transform: rotate(-60deg) scale(0.92)  translate(20px, -18px); }
  24%   { transform: rotate(120deg) scale(1.12)  translate(-12px, -15px); }
  32%   { transform: rotate(-140deg)scale(0.95)  translate(25px, 20px); }
  40%   { transform: rotate(200deg) scale(1.10)  translate(-18px, 12px); }
  48%   { transform: rotate(-210deg)scale(0.90)  translate(15px, -25px); }
  56%   { transform: rotate(280deg) scale(1.15)  translate(-20px, 15px); }
  64%   { transform: rotate(-300deg)scale(0.94)  translate(18px, -20px); }
  72%   { transform: rotate(340deg) scale(1.09)  translate(-22px, 18px); }
  80%   { transform: rotate(-380deg)scale(0.96)  translate(20px, -15px); }
  88%   { transform: rotate(420deg) scale(1.13)  translate(-15px, 22px); }
  100%  { transform: rotate(360deg) scale(1)     translate(0, 0); }
}

@keyframes desaparecerCaotico {
  0%   { transform: scale(1)     rotate(0deg)   translateY(0);     opacity: 1; }
  15%  { transform: scale(1.2)   rotate(25deg)  translateY(-50px); opacity: 1; }
  30%  { transform: scale(0.7)   rotate(-40deg) translateY(60px);  opacity: 0.9; }
  45%  { transform: scale(1.3)   rotate(50deg)  translateY(-80px); opacity: 0.7; }
  60%  { transform: scale(0.4)   rotate(-70deg) translateY(120px); opacity: 0.5; }
  80%  { transform: scale(0.12)  rotate(90deg)  translateY(200px); opacity: 0.2; }
  100% { transform: scale(0.03)  rotate(120deg) translateY(500px); opacity: 0; }
}

/* INSTRUCCIONES */
.instrucciones-overlay {
  position: absolute;
  top: 40px;     
  left: 40px;
  text-align: left;       
  z-index: 10;
  pointer-events: none;  
  max-width: 32%;         
}

.instrucciones-texto {
  color: #ffffff;
  font-size: 1.4rem;           
  font-weight: bold;
  line-height: 1.5;
  margin: 0;
  padding: 0;
  background: none;             
  border: none;                 
  border-radius: 0;           
  animation: fadeIn 1.5s ease-out;
}

@keyframes fadeIn {
  from { 
    opacity: 0; 
    transform: translateY(20px); 
  }
  to { 
    opacity: 1; 
    transform: translateY(0); 
  }
}

.cabeza-overlay.has-started .instrucciones-overlay {
  display: none;
}

</style>