<template>
  <div class="reflexion">
    <div class="imagen-container" v-if="!showCabeza && !showCorazon && !showAbdomen && !showPierna">
      <img src="../assets/imagenes/cuerpo.png" alt="cuerpo" class="img-cuerpo" />
      <img src="../assets/imagenes/cerebro.png" alt="cerebro" class="img-cerebro" @click="openCabeza" />
      <img src="../assets/imagenes/corazon.png" alt="corazon" class="img-corazon" @click="openCorazon"/>
      <img src="../assets/imagenes/nudo.png" alt="estomago" class="img-estomago" @click="openAbdomen"/>
      <img src="../assets/imagenes/musculo.png" alt="musculo" class="img-musculo" @click="openPierna" />
    </div>

    <cabeza 
      v-if="showCabeza && cabezaData"
      :imagen="cabezaData.imagen"
      :instrucciones="cabezaData.instrucciones"
      :frase-mala1="cabezaData.fraseMala1"
      :frase-mala2="cabezaData.fraseMala2"
      :frase-mala3="cabezaData.fraseMala3"
      :frase-buena1="cabezaData.fraseBuena1"
      :frase-buena2="cabezaData.fraseBuena2"
      @close="closeCabeza" 
    />
   
    <pecho
      v-if="showCorazon && corazonData"
      :imagen="corazonData.imagen"
      :instrucciones="corazonData.instrucciones"
      @close="closeCorazon"
    />

    <abdomen
      v-if="showAbdomen && abdomenData"
      :imagen="abdomenData.imagen"
      :instrucciones="abdomenData.instrucciones"
      @close="closeAbdomen"
    />

    <pierna
      v-if="showPierna && piernaData"
      :imagen="piernaData.imagen"
      :instrucciones="piernaData.instrucciones"
      @close="closePierna"
      @reiniciar="resetApp"
    />
  </div>
</template>

<script>
import pierna from '../components/pierna.vue'
import cabeza from '../components/cabeza.vue'
import pecho from '../components/pecho.vue'
import abdomen from '../components/abdomen.vue'
import cabezaImg from '../assets/imagenes/cabeza.png' 
import corazonImg from '../assets/imagenes/corazon.png' 
import abdomenImg from '../assets/imagenes/nudo.png' 
import piernaImg from '../assets/imagenes/musculo.png' 

export default {
  components: { abdomen, pierna, cabeza, pecho  },

  data() {
    return {
      cabezaData: null,
      corazonData: null,
      abdomenData: null,
      piernaData: null,
      error: null,
      showCabeza: false,
      showCorazon: false,
      showAbdomen: false,
      showPierna: false,

    }
  },

  methods: {
    openCabeza() {
      if (this.cabezaData) {
        this.cabezaData.imagen = cabezaImg 
        this.showCabeza = true
      }
    },
    closeCabeza() {
      this.showCabeza = false
    },

    openCorazon() {
      if (this.corazonData) {
        this.corazonData.imagen = corazonImg
        this.showCorazon = true
      }
    },
    closeCorazon() {
      this.showCorazon = false
    },

    openAbdomen() {
      if (this.abdomenData) {
        this.abdomenData.imagen = abdomenImg
        this.showAbdomen = true
      }
    },
    closeAbdomen() {
      this.showAbdomen = false
    },

    openPierna() {
      if (this.piernaData) {
        this.piernaData.imagen = piernaImg
        this.showPierna = true
      }
    },
    closePierna() {
      this.showPierna = false
    },

    closePierna() {
    this.showPierna = false
    },
    
    resetApp() {
      this.showCabeza = false
      this.showCorazon = false
      this.showAbdomen = false
      this.showPierna = false
    },
  },

  mounted() {
    fetch('/levelup/cerebro.json')
      .then(res => {
        if (!res.ok) throw new Error("No se pudo cargar el JSON");
        return res.json();
      })
      .then(data => {
        this.cabezaData = data;
      })
      .catch(err => {
        this.error = err.message;
        console.error(err);
    });

    fetch('/levelup/corazon.json')
      .then(res => {
        if (!res.ok) throw new Error("No se pudo cargar corazon.json");
        return res.json();
      })
      .then(data => {
        this.corazonData = data;
      })
      .catch(err => {
        this.error = err.message;
        console.error(err);
    });
  
    fetch('/levelup/estomago.json')
      .then(res => {
        if (!res.ok) throw new Error("No se pudo cargar abdomen.json");
        return res.json();
      })
      .then(data => {
        this.abdomenData = data;
      })
      .catch(err => {
        this.error = err.message;
        console.error(err);
    });

    fetch('/levelup/hueso.json')
      .then(res => {
        if (!res.ok) throw new Error("No se pudo cargar pierna.json");
        return res.json();
      })
      .then(data => {
        this.piernaData = data;
      })
      .catch(err => {
        this.error = err.message;
        console.error(err);
    });
  }
}
</script>

<style>
.reflexion {
  background: rgb(152, 1, 1);
  color: white;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

.imagen-container {
  position: relative;
  display: inline-block;
  width: 30%;
}

.img-cuerpo {
  display: block;
  width: 100%;
  margin-top: 10%;
  margin-bottom: 20%;
}

.img-cerebro {
  position: absolute;
  top: 5%;
  left: 50%;
  transform: translateX(-50%);
  width: 20%;
  cursor: pointer;
}

.img-corazon {
  position: absolute;
  bottom: 72%;
  left: 60%;
  transform: translateX(-50%);
  width: 15%;
}

.img-estomago{
  position: absolute;
  bottom: 55%;
  left: 50%;
  transform: translateX(-50%);
  width: 25%;
}

.img-musculo{
  position: absolute;
  bottom: 25%;
  left: 33%;
  transform: translateX(-50%);
  width: 13%;
}
</style>