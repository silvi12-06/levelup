<template>
  <pesasfondo/>
  <div class="about">
    <div class="contenedor-centrado" :class="{ 'entering': isEntering }">
      <div class="hero-black"></div>
      <div class="titulo">
        <h1>ACERCA DE</h1>
      </div>
      <div class="contenido">
        <p>Esta web es una reinterpretación del gimnasio como espacio para escucharnos. Frente a la idea tradicional de entrenar para corregir, forzar o alcanzar un ideal de cuerpo, esta experiencia propone una pausa: escuchar lo que el cuerpo siente, piensa y guarda.</p>
        <p>Lejos de mostrar transformaciones externas, esta web se centra en la transformación interna. El cuerpo no aparece como una máquina que hay que arreglar, sino como un espacio que necesita atención y respeto. Cada interacción invita a reflexionar sobre la relación que tenemos con el ejercicio, la autoexigencia y la forma en que nos tratamos a nosotros mismos.</p>
        <p>Porque cuidarse no es castigarse. Cuidarse es escuchar.</p>
      </div>
    </div>
  </div>
</template>

<script>
import pesasfondo from '../components/pesasfondo.vue'; 
export default {
  components: {
    pesasfondo
  },
  data() {
    return {
      isEntering: false  
    }
  },
  mounted() {
    setTimeout(() => {
      this.isEntering = true
    }, 100) 
  }
}
</script>

<style scoped>
.home, .about {
position: relative;  
overflow: hidden;    
}
.about {
  background: black;
  color: white;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 40px 20px;
  overflow: hidden;
}

.hero-black {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 80vw;          
  max-width: 800px;
  height: 80vh;          
  max-height: 700px;
  background: rgba(0, 0, 0, 0.85);
  border-radius: 20px;   
  z-index: -1;          
  pointer-events: none;
}

.contenedor-centrado {
  display: flex;
  flex-direction: column;
  align-items: center;
  max-width: 800px;
  width: 100%;
  text-align: center;
  position: relative;
  z-index: 10;
  opacity: 0;
  transform: translateY(100vh);
  transition: all 1.8s cubic-bezier(0.25, 0.8, 0.25, 1);
  gap: 50px; 
}

.contenedor-centrado.entering {
  opacity: 1;
  transform: translateY(0);
}

.titulo h1 {
  font-size: 2rem;
  letter-spacing: 0.15em;
  text-transform: uppercase;
}

.contenido {
  font-size: 1.25rem;
  line-height: 1.9;
  max-width: 700px;
}
</style>