<template>
  <pesasfondo/>
  <div class="home">
    <!-- Título con botón Play superpuesto -->
    <div class="titulo" :class="{ 'animate-up': isAnimating }" >
    <!-- Hero negro (fondo sólido sutil) -->
      <div class="hero-black"></div>

      <!-- Contenedor relativo para la imagen y el overlay -->
      <div class="levelup-container">
        <img src="../assets/imagenes/levelup.png" alt="LevelUP" class="img-levelup" />
        
        <!-- Botón Play superpuesto -->
        <div class="play-button" @click="startAnimation">
          <img src="../assets/imagenes/play.png" alt="Play" class="img-play" />
        </div>
      </div>
      
      <h1>ENTRENA TU MENTE</h1>
     
    </div>
  </div>
</template>

<script>
import pesasfondo from '../components/pesasfondo.vue';  // Ajusta la ruta si tu carpeta es diferente
export default {
  components: {
    pesasfondo
  },
  data() {
    return {
      isAnimating: false,
    };
  },
  methods: {
    startAnimation() {
      if (this.isAnimating) return;
      this.isAnimating = true;

      // Después de que termine la animación (1.8s), vamos a /about
      setTimeout(() => {
        this.$router.push('/about');
      }, 1800);
    },
  },
};
</script>

<style>
.home, .about {
  position: relative;   /* Importante para que el absolute de PesasFondo funcione */
  overflow: hidden;     /* Ya lo tienes */
}
.home {
  background: black;
  color: white;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  overflow: hidden;
}

.titulo {
  position: relative;
  display: inline-block;
  width: 100%;
  text-align: center;
  z-index: 10;
}

/* Hero negro sólido detrás del contenido central */
.hero-black {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 80vw;           /* Ancho grande pero no cubre toda la pantalla */
  max-width: 600px;
  height: 80vh;          /* Alto grande */
  max-height: 700px;
  background: rgba(0, 0, 0, 0.7);
  /* Opcional: negro puro → background: rgba(0, 0, 0, 0.8); */
  border-radius: 20px;   /* Bordes redondeados sutiles (opcional, quita si quieres recto) */
  z-index: -1;           /* Detrás del logo, play y texto */
  pointer-events: none;
}

/* Contenedor para la imagen y el play overlay */
.levelup-container {
  position: relative;
  display: inline-block;
  left: 28%; /* Mantiene el centrado aproximado de la imagen */
}

/* Imagen LevelUP */
.img-levelup {
  display: block;
  width: 45%;
  height: auto;
  pointer-events: none;
  margin-bottom: 10%;
}

/* Botón Play superpuesto */
.play-button {
  position: absolute;
  bottom: 30%; /* Ajusta para moverlo arriba/abajo dentro de la imagen */
  left: 18%;
  transform: translateX(-50%);
  width: 10%; /* Tamaño relativo al contenedor (ajusta según tu icono) */
  cursor: pointer;
  transition: transform 0.3s ease, filter 0.3s ease;
  pointer-events: auto; /* Permite el clic solo en el botón */
}

.play-button:hover {
  transform: translateX(-50%) scale(1.15);
  filter: brightness(1.3); /* Brillo extra al hover */
}

.img-play {
  width: 100%;
  height: auto;
  pointer-events: none;
}

.titulo h1 {
  position: absolute;
  top: 85%; /* Ajustado para dejar espacio debajo de la imagen */
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
  margin: 0;
  font-size: 2em;
  pointer-events: none;
}

/* Animación de subida */
.animate-up {
  animation: flyUp 1.8s cubic-bezier(0.25, 0.8, 0.25, 1) forwards;
}

@keyframes flyUp {
  0% { 
    transform: translateY(0);
    opacity: 1;
  }
  100% { 
    transform: translateY(-120vh);
    opacity: 0;
  }
}


</style>